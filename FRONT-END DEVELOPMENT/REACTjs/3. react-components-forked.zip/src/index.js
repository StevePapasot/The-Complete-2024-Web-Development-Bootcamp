import React from "react";
import ReactDOM from "react-dom";
import Heading from "./Heading.jsx";
import List from "./List.jsx";
import App from "./App.jsx";

ReactDOM.render(<App />, document.getElementById("root"));
